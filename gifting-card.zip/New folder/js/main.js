/* =====================================================
   PAPYRUS CARDS - JavaScript Interactions
   ===================================================== */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initLoader();
    initNavigation();
    initThemeToggle();
    initTicker();
    initHeroAnimations();
    initCategoryCards();
    initCarousel();
    initAIGenerator();
    initModal();
    initSmoothScroll();
});

/* =====================================================
   LOADER
   ===================================================== */
function initLoader() {
    const loader = document.querySelector('.loader');
    const progress = document.querySelector('.loader-progress');
    
    window.addEventListener('load', function() {
        setTimeout(() => {
            progress.style.animationPlayState = 'paused';
            loader.classList.add('hidden');
        }, 2000);
    });
}

/* =====================================================
   NAVIGATION
   ===================================================== */
function initNavigation() {
    const navbar = document.querySelector('.navbar');
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const mobileMenu = document.querySelector('.mobile-menu');
    const navLinks = document.querySelectorAll('.nav-link');
    
    // Scroll effect
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
    
    // Mobile menu toggle
    mobileMenuBtn.addEventListener('click', function() {
        mobileMenu.classList.toggle('active');
        this.classList.toggle('active');
    });
    
    // Close mobile menu on link click
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            mobileMenu.classList.remove('active');
            mobileMenuBtn.classList.remove('active');
        });
    });
    
    // Active link highlighting
    const sections = document.querySelectorAll('section[id]');
    
    window.addEventListener('scroll', function() {
        let current = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            
            if (scrollY >= sectionTop - 200) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href').slice(1) === current) {
                link.classList.add('active');
            }
        });
    });
}

/* =====================================================
   THEME TOGGLE
   ===================================================== */
function initThemeToggle() {
    const themeToggle = document.getElementById('themeToggle');
    const icon = themeToggle.querySelector('i');
    
    // Check for saved theme preference
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        document.documentElement.setAttribute('data-theme', savedTheme);
        updateThemeIcon(savedTheme);
    }
    
    themeToggle.addEventListener('click', function() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        updateThemeIcon(newTheme);
        
        // Add rotation animation
        this.style.transform = 'rotate(360deg)';
        setTimeout(() => {
            this.style.transform = '';
        }, 300);
    });
    
    function updateThemeIcon(theme) {
        if (theme === 'light') {
            icon.classList.remove('fa-moon');
            icon.classList.add('fa-sun');
        } else {
            icon.classList.remove('fa-sun');
            icon.classList.add('fa-moon');
        }
    }
}

/* =====================================================
   TICKER
   ===================================================== */
function initTicker() {
    updateDateTime();
    setInterval(updateDateTime, 1000);
    
    function updateDateTime() {
        const now = new Date();
        
        const dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const timeOptions = { hour: '2-digit', minute: '2-digit', second: '2-digit' };
        
        const dateStr = now.toLocaleDateString('en-US', dateOptions);
        const timeStr = now.toLocaleTimeString('en-US', timeOptions);
        
        const dateElements = document.querySelectorAll('#currentDate, #currentDate2');
        const timeElements = document.querySelectorAll('#currentTime, #currentTime2');
        
        dateElements.forEach(el => el.textContent = dateStr);
        timeElements.forEach(el => el.textContent = timeStr);
    }
}

/* =====================================================
   HERO ANIMATIONS
   ===================================================== */
function initHeroAnimations() {
    // Animate stats counter
    const statNumbers = document.querySelectorAll('.stat-number');
    
    statNumbers.forEach(stat => {
        const target = parseInt(stat.getAttribute('data-count'));
        
        gsap.to(stat, {
            duration: 2,
            ease: 'power2.out',
            onUpdate: function() {
                stat.textContent = Math.round(this.targets()[0].textContent).toLocaleString();
            }
        });
    });
    
    // Floating cards parallax
    const floatingCards = document.querySelectorAll('.floating-card');
    
    window.addEventListener('scroll', function() {
        const scrollY = window.scrollY;
        
        floatingCards.forEach((card, index) => {
            const speed = 0.1 + (index * 0.05);
            card.style.transform = `translateY(${scrollY * speed}px)`;
        });
    });
    
    // GSAP animations for hero
    gsap.from('.hero-badge', {
        duration: 0.8,
        y: 30,
        opacity: 0,
        delay: 0.2
    });
    
    gsap.from('.hero-title .title-line', {
        duration: 0.8,
        y: 50,
        opacity: 0,
        stagger: 0.2
    });
    
    gsap.from('.hero-subtitle', {
        duration: 0.8,
        y: 30,
        opacity: 0,
        delay: 0.6
    });
    
    gsap.from('.hero-actions', {
        duration: 0.8,
        y: 30,
        opacity: 0,
        delay: 0.8
    });
    
    gsap.from('.hero-stats', {
        duration: 0.8,
        y: 30,
        opacity: 0,
        delay: 1
    });
    
    // Floating cards entrance
    gsap.from('.floating-card', {
        duration: 1,
        scale: 0,
        opacity: 0,
        stagger: 0.2,
        delay: 0.5,
        ease: 'back.out(1.7)'
    });
}

/* =====================================================
   CATEGORY CARDS
   ===================================================== */
function initCategoryCards() {
    const categoryCards = document.querySelectorAll('.category-card');
    
    categoryCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            // Add tilt effect
            this.style.transform = 'translateY(-10px) scale(1.02)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = '';
        });
    });
    
    // Showcase cards 3D effect
    const showcaseCards = document.querySelectorAll('.showcase-card');
    
    showcaseCards.forEach(card => {
        card.addEventListener('mousemove', function(e) {
            const rect = this.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const rotateX = (y - centerY) / 10;
            const rotateY = (centerX - x) / 10;
            
            this.querySelector('.showcase-card-inner').style.transform = 
                `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
        });
        
        card.addEventListener('mouseleave', function() {
            this.querySelector('.showcase-card-inner').style.transform = '';
        });
    });
}

/* =====================================================
   CAROUSEL
   ===================================================== */
function initCarousel() {
    const track = document.querySelector('.carousel-track');
    const cards = document.querySelectorAll('.carousel-card');
    const prevBtn = document.querySelector('.carousel-prev');
    const nextBtn = document.querySelector('.carousel-next');
    const dotsContainer = document.querySelector('.carousel-dots');
    
    let currentIndex = 0;
    const cardWidth = 330; // card width + gap
    const totalCards = cards.length;
    const visibleCards = Math.floor(track.parentElement.offsetWidth / cardWidth);
    
    // Create dots
    for (let i = 0; i < totalCards - visibleCards + 1; i++) {
        const dot = document.createElement('div');
        dot.classList.add('carousel-dot');
        if (i === 0) dot.classList.add('active');
        dot.addEventListener('click', () => goToSlide(i));
        dotsContainer.appendChild(dot);
    }
    
    const dots = document.querySelectorAll('.carousel-dot');
    
    function updateDots() {
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === currentIndex);
        });
    }
    
    function goToSlide(index) {
        currentIndex = index;
        track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
        updateDots();
    }
    
    function nextSlide() {
        if (currentIndex < totalCards - visibleCards) {
            currentIndex++;
        } else {
            currentIndex = 0;
        }
        goToSlide(currentIndex);
    }
    
    function prevSlide() {
        if (currentIndex > 0) {
            currentIndex--;
        } else {
            currentIndex = totalCards - visibleCards;
        }
        goToSlide(currentIndex);
    }
    
    nextBtn.addEventListener('click', nextSlide);
    prevBtn.addEventListener('click', prevSlide);
    
    // Auto-advance
    let autoSlide = setInterval(nextSlide, 4000);
    
    track.addEventListener('mouseenter', () => clearInterval(autoSlide));
    track.addEventListener('mouseleave', () => autoSlide = setInterval(nextSlide, 4000));
    
    // Carousel card tilt effect
    cards.forEach(card => {
        card.addEventListener('mousemove', function(e) {
            const rect = this.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const rotateX = (y - centerY) / 15;
            const rotateY = (centerX - x) / 15;
            
            this.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(10px)`;
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = '';
        });
        
        // Open modal on click
        card.addEventListener('click', function() {
            const emoji = this.querySelector('.carousel-emoji').textContent;
            const title = this.querySelector('h4').textContent;
            const author = this.querySelector('.carousel-author').textContent;
            const price = this.querySelector('.price').textContent;
            const downloads = this.querySelector('.downloads').textContent;
            
            openModal(emoji, title, author, price, downloads);
        });
    });
}

/* =====================================================
   AI GENERATOR
   ===================================================== */
function initAIGenerator() {
    const generateBtn = document.getElementById('generateBtn');
    const greetingInput = document.getElementById('greetingInput');
    const occasionSelect = document.getElementById('occasionSelect');
    const toneSelect = document.getElementById('toneSelect');
    const giftBox = document.getElementById('giftBox');
    const giftWrapper = document.querySelector('.gift-box-wrapper');
    const greetingCardPopup = document.getElementById('greetingCardPopup');
    const popupMessage = document.getElementById('popupMessage');
    const popupOccasion = document.getElementById('popupOccasion');
    const generatedResult = document.getElementById('generatedResult');
    const resultMessage = document.getElementById('resultMessage');
    const copyBtn = document.getElementById('copyBtn');
    const downloadBtn = document.getElementById('downloadBtn');
    const shareBtn = document.getElementById('shareBtn');
    const regenerateBtn = document.getElementById('regenerateBtn');
    
    let isAnimating = false;
    let currentMessage = '';
    
    // Greeting templates
    const greetingTemplates = {
        birthday: {
            heartfelt: [
                "Happy Birthday! 🎂 May your special day be filled with love, laughter, and all your favorite things. You deserve the best year ahead!",
                "Wishing you a fantastic birthday! 🎉 May this new chapter of your life bring you endless joy, success, and beautiful memories. Celebrate big!",
                "Happy Birthday, dear friend! 🎈 Today we celebrate YOU - an amazing person who makes the world brighter. Have an incredible day!"
            ],
            funny: [
                "Happy Birthday! 🎂 You're not getting older, you're just leveling up! Hope your level 25 brings lots of XP (extra pizza)!",
                "Congratulations on surviving another year! 🎉 You've officially earned your 'Adulting' badge. Now let's celebrate with cake!",
                "Happy Birthday! 🎈 They say age is just a number. But in your case, it's a really big number... just kidding! You're still young at heart!"
            ],
            romantic: [
                "My love, happy birthday! 💕 Every moment with you is a gift. Here's to another year of beautiful memories together. I love you!",
                "Happy Birthday to the most amazing person in my life! ❤️ You make every day feel like Valentine's Day. I love you more each day!",
                "To my everything, happy birthday! 🌹 You are the best gift I've ever received. Here's to forever together. Love you always!"
            ],
            formal: [
                "Please accept my warmest wishes on your birthday. 🎂 May this year bring you success, happiness, and good health.",
                "Wishing you a very happy birthday! 🎉 May your special day be celebrated with joy and surrounded by loved ones.",
                "Happy Birthday! 🎈 I hope this year brings you all the success and happiness you deserve. Have a wonderful celebration!"
            ],
            casual: [
                "Hey! Happy birthday! 🎂 Hope you have an awesome day! Let's celebrate soon!",
                "Yay! It's your birthday! 🎉 Have a great one and enjoy every moment!",
                "Happy birthday, buddy! 🎈 Hope it's a blast! Let's hang out soon!"
            ]
        },
        anniversary: {
            heartfelt: [
                "Happy Anniversary! 💍 Another year of beautiful memories together. Here's to many more years of love and happiness!",
                "Congratulations on another year together! ❤️ May your love continue to grow stronger with each passing day. You two are goals!",
                "Happy Anniversary! 🎉 Time flies when you're in love. Wishing you both endless happiness and many more years together!"
            ],
            funny: [
                "Happy Anniversary! 🎉 You've managed to tolerate each other for another year. That's true love! Here's to many more!",
                "Congratulations on surviving another year of marriage! 💍 Hopefully the next year involves less arguing about the remote!",
                "Happy Anniversary! 🥂 They say the secret to a long marriage is separate bathrooms. Just kidding! Love you both!"
            ],
            romantic: [
                "Happy Anniversary, my love! 💕 Every day with you is a blessing. Here's to our love story continuing forever!",
                "My heart, happy anniversary! ❤️ You are my everything. I'm so grateful for every moment we've shared. I love you!",
                "To my soulmate, happy anniversary! 🌹 You make my world complete. Here's to forever and always. I love you!"
            ],
            formal: [
                "Wishing you a very Happy Anniversary. 🎂 May your union continue to flourish with love and happiness.",
                "Congratulations on your anniversary! 🥂 May this special day bring you joy and many more happy years together.",
                "Happy Anniversary! 💐 Your partnership is an inspiration. Wishing you continued happiness and love."
            ],
            casual: [
                "Hey! Happy anniversary! 🎉 You two are the cutest! Hope you have an amazing day!",
                "Yay! Happy anniversary! 💕 Have a great celebration! Love you guys!",
                "Happy anniversary! 🎂 Here's to many more years of love and laughter!"
            ]
        },
        'mothers-day': {
            heartfelt: [
                "Happy Mother's Day, Mom! 💐 You are my rock, my inspiration, and my best friend. Thank you for everything you do!",
                "To the most amazing mom in the world, Happy Mother's Day! ❤️ Your love and sacrifice shaped who I am. I love you!",
                "Happy Mother's Day, Mom! 🌸 You are the heartbeat of our family and the light in our lives. Thank you for everything!"
            ],
            funny: [
                "Happy Mother's Day to the woman who made me everything I am... and some things I'm not! 😂 Love you, Mom!",
                "Mom, you're not just a mother, you're a magician! You somehow always know where I hide the snacks! 🎩❤️ Happy Mother's Day!",
                "Happy Mother's Day! 🎉 Thanks for pretending to like my art projects and terrible jokes. You're the best!"
            ],
            romantic: [
                "Happy Mother's Day, my love! 💕 Thank you for being the most amazing mother to our children. You're my hero!",
                "To the most beautiful mother, happy Mother's Day! 🌹 Your strength and love inspire me every day. I adore you!",
                "My darling, happy Mother's Day! ❤️ You're the heart of our home and the love of my life. I appreciate you!"
            ],
            formal: [
                "With deepest gratitude on Mother's Day. 💐 Your nurturing spirit and unconditional love are truly appreciated.",
                "Wishing you a very Happy Mother's Day. 🥂 May your day be filled with the love and appreciation you deserve.",
                "Happy Mother's Day! 🌸 Thank you for your endless love and dedication. You are greatly appreciated."
            ],
            casual: [
                "Hey Mom! Happy Mother's Day! ❤️ Hope you have an awesome day relaxing! Love you!",
                "Happy Mother's Day, Mom! 🎉 You're the best! Thanks for everything you do!",
                "Love you, Mom! Happy Mother's Day! 💐 Have a great day!"
            ]
        },
        'new-year': {
            heartfelt: [
                "Happy New Year! 🎆 May this year bring you joy, success, and all your heart desires. Here's to new beginnings!",
                "Wishing you a wonderful New Year! 🥂 May 2024 be your best year yet filled with love and happiness!",
                "Happy New Year! 🎉 May this year be filled with amazing opportunities and beautiful moments. Cheers to new adventures!"
            ],
            funny: [
                "Happy New Year! 🎆 Remember, this year your only limit is yourself... and physics! Have an awesome year!",
                "New year, new me? Nah, same awesome me! 😂 But I hope this year brings you lots of cake and naps!",
                "Happy New Year! 🥂 Let's make this year so good that last year looks like a rough draft!"
            ],
            romantic: [
                "Happy New Year, my love! 💕 Every moment with you feels like a celebration. Here's to an amazing year together!",
                "My darling, happy new year! ❤️ May our love grow stronger each day. I can't wait to make more memories with you!",
                "To my everything, happy new year! 🌹 You are the best thing that happened to me. Here's to us!"
            ],
            formal: [
                "Wishing you a very Happy New Year! 🥂 May this year bring you success, health, and happiness.",
                "Happy New Year! 🎆 I hope this year fulfills all your dreams and aspirations. Best wishes for the year ahead!",
                "Happy New Year! 🎉 May the new year bring you peace, prosperity, and joy."
            ],
            casual: [
                "Hey! Happy New Year! 🎉 Hope this year is awesome for you! Let's make it happen!",
                "Yay! New Year, new adventures! 🥂 Have an amazing year!",
                "Happy New Year! 🎆 Let's make this one the best yet!"
            ]
        },
        friendship: {
            heartfelt: [
                "Happy Friendship Day! 🤝 You're more than a friend, you're family. Thank you for being always there for me!",
                "To my best friend, happy friendship day! 💕 Your friendship is the greatest gift. I love you!",
                "Happy Friendship Day! 🌟 Friends like you are rare and precious. Thank you for everything!"
            ],
            funny: [
                "Happy Friendship Day! 😂 You're the friend who judges me but still loves me. That's real friendship!",
                "Happy Friend Day! 🎉 Thanks for being the partner in crime I always needed!",
                "Friend, you're the best! 😂 Happy Friendship Day! Thanks for all the bad ideas and good times!"
            ],
            romantic: [
                "Happy Friendship Day, my dear friend! 💕 You hold a special place in my heart. Love you!",
                "To my soulmate friend, happy friendship day! ❤️ You've been with me through it all. Forever grateful!",
                "My favorite person, happy friendship day! 🌹 Your friendship means everything to me. Love you!"
            ],
            formal: [
                "Wishing you a very Happy Friendship Day. 🤝 Your friendship is truly valued and appreciated.",
                "Happy Friendship Day! 🌟 May our bond of friendship continue to grow stronger.",
                "Happy Friendship Day! 💐 I'm grateful for your friendship and support throughout the years."
            ],
            casual: [
                "Hey bestie! Happy Friendship Day! 🎉 Love you loads!",
                "Happy Friend Day! 🤜🤛 You're the best! Love ya!",
                "Yay! Friendship Day! 🎊 Thanks for being awesome, friend!"
            ]
        },
        christmas: {
            heartfelt: [
                "Merry Christmas! 🎄 May your holidays be filled with love, joy, and warmth. Happy holidays to you and your family!",
                "Wishing you a magical Christmas! 🎁 May this festive season bring you peace and happiness. Have a wonderful holiday!",
                "Merry Christmas! ⛄ May your home be filled with laughter and your heart with love this holiday season!"
            ],
            funny: [
                "Merry Christmas! 🎅 May your coffee be strong and your holidays be stress-free!",
                "Happy Holidays! 🎄 Remember, Santa sees everything... but don't worry, I've got your coal! 😂",
                "Merry Christmas! 🎁 May your gifts be exactly what you wanted and your family be less awkward!"
            ],
            romantic: [
                "Merry Christmas, my love! 💕 You're the best gift I've ever received. I love you!",
                "My darling, merry christmas! ❤️ Spending the holidays with you is the greatest gift. I love you!",
                "Merry Christmas, sweetheart! 🌹 You've made my life complete. I love you more than Santa loves cookies!"
            ],
            formal: [
                "Wishing you a very Merry Christmas! 🎄 May your holiday season be filled with joy and peace.",
                "Merry Christmas! ⛄ I hope your celebrations are delightful and your new year is prosperous.",
                "Happy Holidays! 🎁 May this special time of year bring you happiness and good health."
            ],
            casual: [
                "Hey! Merry Christmas! 🎄 Hope you have an awesome holiday!",
                "Merry Christmas! 🎁 Have a great time with family and friends!",
                "Happy holidays! 🎊 Enjoy the festive season, friend!"
            ]
        },
        wedding: {
            heartfelt: [
                "Wishing you a lifetime of love and happiness! 💍 May your marriage be as beautiful as your love story!",
                "Congratulations on your wedding! 🥂 Wishing you both endless joy, love, and prosperity. Here's to forever!",
                "Happy Wedding Day! 💕 May your union be blessed with love, laughter, and happily ever after!"
            ],
            funny: [
                "Congratulations! 🎉 You've officially found your person! Now you have someone to blame for the thermostat!",
                "Wedding bells! 🔔 You've found your forever person! Hope they like your weird habits! 😂",
                "Congrats on the wedding! 💍 Now you have a built-in best friend for life! Have an awesome journey!"
            ],
            romantic: [
                "My deepest love and congratulations! 💕 You both deserve all the happiness in the world!",
                "Wishing you both a love that grows stronger each day! ❤️ May your marriage be filled with magic!",
                "Congratulations, my loves! 🌹 Your love story is the most beautiful one I know. Here's to forever!"
            ],
            formal: [
                "Please accept my heartfelt congratulations on your wedding. 💐 Wishing you both a lifetime of happiness.",
                "Congratulations on your marriage! 🥂 May your partnership be blessed with love and prosperity.",
                "Wishing you both a wonderful married life! 💕 May your journey together be filled with joy."
            ],
            casual: [
                "Yay! Congratulations! 🎉 So happy for you both! Have an amazing wedding day!",
                "Congrats! 💍 Wishing you both all the best! Have an awesome celebration!",
                "Happy wedding day! 🎊 You two are the cutest! Have a blast!"
            ]
        },
        graduation: {
            heartfelt: [
                "Congratulations, graduate! 🎓 Your hard work has paid off! Wishing you success and happiness in all your endeavors!",
                "Well done, graduate! 🎓 You've achieved something amazing! May your future be as bright as your smile today!",
                "Congratulations on your graduation! 🎓 This is just the beginning of an incredible journey. Best of luck!"
            ],
            funny: [
                "Congratulations! 🎓 You're officially allowed to be an adult now! Good luck with that! 😂",
                "Look at you, all educated! 🎓 Now you can finally use 'I have a degree' as an excuse! 🎉",
                "Graduation accomplished! 🎓 Time to join the real world... or maybe grad school! 😂 Just kidding, congrats!"
            ],
            romantic: [
                "My brilliant graduate, I'm so proud of you! 💕 Your determination inspires me every day. Love you!",
                "Congratulations, sweetheart! 🎓 You've done it! I'm so honored to be part of your journey. Love you!",
                "My love, congratulations on your graduation! ❤️ Watching you succeed brings me so much joy. I'm so proud!"
            ],
            formal: [
                "Hearty congratulations on your graduation! 🎓 Wishing you continued success in all your future endeavors.",
                "Congratulations on this remarkable achievement! 🎓 May your career path be filled with success and fulfillment.",
                "Well done, graduate! 🎓 Your hard work and dedication have paid off. Best wishes for your future!"
            ],
            casual: [
                "Hey! Congratulations, grad! 🎓 So proud of you! Let's celebrate!",
                "Yay! You did it! 🎉 Awesome job, graduate!",
                "Congrats! 🎓 Have an amazing future! So excited for you!"
            ]
        }
    };
    
    generateBtn.addEventListener('click', async function() {
        if (isAnimating) return;
        
        const input = greetingInput.value.trim();
        if (!input) {
            greetingInput.focus();
            greetingInput.style.animation = 'shake 0.5s ease';
            setTimeout(() => greetingInput.style.animation = '', 500);
            return;
        }
        
        isAnimating = true;
        
        // Show gift box animation
        giftWrapper.classList.add('opening');
        
        // Generate greeting based on input
        const occasion = occasionSelect.value;
        const tone = toneSelect.value;
        
        // Simulate AI generation delay
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Generate greeting
        currentMessage = generateGreeting(input, occasion, tone);
        
        // Show card popup
        popupOccasion.textContent = occasionSelect.options[occasionSelect.selectedIndex].text;
        popupMessage.textContent = currentMessage;
        
        setTimeout(() => {
            giftWrapper.classList.add('hidden');
            greetingCardPopup.classList.add('show');
            
            // Trigger confetti
            triggerConfetti();
            
            // Show result
            setTimeout(() => {
                generatedResult.classList.add('show');
                resultMessage.textContent = currentMessage;
                isAnimating = false;
            }, 1500);
            
        }, 1000);
    });
    
    function generateGreeting(input, occasion, tone) {
        const templates = greetingTemplates[occasion]?.[tone] || greetingTemplates.birthday.heartfelt;
        
        // Add some variation based on input
        let message = templates[Math.floor(Math.random() * templates.length)];
        
        // Check for keywords in input
        if (input.toLowerCase().includes('best friend') || input.toLowerCase().includes('friend')) {
            message = templates[Math.floor(Math.random() * templates.length)];
        }
        
        return message;
    }
    
    function triggerConfetti() {
        const duration = 3000;
        const end = Date.now() + duration;
        
        (function frame() {
            confetti({
                particleCount: 5,
                angle: 60,
                spread: 55,
                origin: { x: 0 },
                colors: ['#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', '#fbbf24']
            });
            confetti({
                particleCount: 5,
                angle: 120,
                spread: 55,
                origin: { x: 1 },
                colors: ['#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', '#fbbf24']
            });
            
            if (Date.now() < end) {
                requestAnimationFrame(frame);
            }
        })();
    }
    
    // Copy button
    copyBtn.addEventListener('click', function() {
        navigator.clipboard.writeText(currentMessage).then(() => {
            this.innerHTML = '<i class="fas fa-check"></i>';
            setTimeout(() => {
                this.innerHTML = '<i class="fas fa-copy"></i>';
            }, 2000);
        });
    });
    
    // Download button - simplified without html2canvas for reliability
    downloadBtn.addEventListener('click', function() {
        // Create a text-based card content
        const cardContent = `
╔═══════════════════════════════════════╗
║         ${occasionSelect.options[occasionSelect.selectedIndex].text.toUpperCase()}         ║
╠═══════════════════════════════════════╣
║                                       ║
║  ${currentMessage}  ║
║                                       ║
╠═══════════════════════════════════════╣
║           — Papyrus Cards —           ║
╚═══════════════════════════════════════╝
        `;
        
        // Copy to clipboard
        navigator.clipboard.writeText(cardContent).then(() => {
            downloadBtn.innerHTML = '<i class="fas fa-check"></i> Copied!';
            setTimeout(() => {
                downloadBtn.innerHTML = '<i class="fas fa-download"></i> Download';
            }, 2000);
        });
    });
    
    // Share button
    shareBtn.addEventListener('click', function() {
        if (navigator.share) {
            navigator.share({
                title: 'Papyrus Cards - Greeting',
                text: currentMessage,
                url: window.location.href
            });
        } else {
            // Fallback
            navigator.clipboard.writeText(currentMessage);
            this.innerHTML = '<i class="fas fa-check"></i> Copied!';
            setTimeout(() => {
                this.innerHTML = '<i class="fas fa-share-alt"></i> Share';
            }, 2000);
        }
    });
    
    // Regenerate button
    regenerateBtn.addEventListener('click', function() {
        // Reset animation
        greetingCardPopup.classList.remove('show');
        giftWrapper.classList.remove('hidden', 'opening');
        generatedResult.classList.remove('show');
        
        // Generate new message
        const occasion = occasionSelect.value;
        const tone = toneSelect.value;
        
        const templates = greetingTemplates[occasion]?.[tone] || greetingTemplates.birthday.heartfelt;
        currentMessage = templates[Math.floor(Math.random() * templates.length)];
        
        setTimeout(() => {
            popupMessage.textContent = currentMessage;
            resultMessage.textContent = currentMessage;
            generatedResult.classList.add('show');
        }, 500);
    });
}

/* =====================================================
   MODAL
   ===================================================== */
function initModal() {
    const modal = document.getElementById('cardModal');
    const modalClose = document.getElementById('modalClose');
    const modalOverlay = document.querySelector('.modal-overlay');
    
    modalClose.addEventListener('click', closeModal);
    modalOverlay.addEventListener('click', closeModal);
    
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') closeModal();
    });
    
    function closeModal() {
        modal.classList.remove('active');
    }
    
    window.openModal = function(emoji, title, author, price, downloads) {
        document.getElementById('modalEmoji').textContent = emoji;
        document.getElementById('modalTitle').textContent = title;
        document.getElementById('modalDescription').textContent = `Created with love by ${author}`;
        
        // Set category from title (simplified)
        let category = 'Birthday';
        if (title.toLowerCase().includes('love') || title.toLowerCase().includes('forever')) {
            category = 'Anniversary';
        } else if (title.toLowerCase().includes('friend')) {
            category = 'Friendship';
        } else if (title.toLowerCase().includes('mom') || title.toLowerCase().includes('mother')) {
            category = "Mother's Day";
        } else if (title.toLowerCase().includes('christmas') || title.toLowerCase().includes('winter')) {
            category = 'Christmas';
        } else if (title.toLowerCase().includes('new year')) {
            category = 'New Year';
        } else if (title.toLowerCase().includes('graduation')) {
            category = 'Graduation';
        } else if (title.toLowerCase().includes('baby')) {
            category = 'Baby';
        }
        
        document.getElementById('modalCategory').textContent = category;
        document.getElementById('modalRating').textContent = (Math.random() * 0.5 + 4.5).toFixed(1) + '/5';
        document.getElementById('modalDownloads').textContent = downloads.replace(' ', '');
        document.getElementById('modalPrice').textContent = price;
        
        modal.classList.add('active');
    };
}

/* =====================================================
   SMOOTH SCROLL
   ===================================================== */
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            
            if (target) {
                const headerOffset = 80;
                const elementPosition = target.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

/* =====================================================
   GSAP SCROLL TRIGGER ANIMATIONS
   ===================================================== */
gsap.registerPlugin(ScrollTrigger);

// Animate sections on scroll
gsap.utils.toArray('section').forEach(section => {
    gsap.from(section.querySelectorAll('.section-header > *'), {
        scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
        },
        duration: 0.8,
        y: 30,
        opacity: 0,
        stagger: 0.1
    });
});

// Category cards animation
gsap.from('.category-card', {
    scrollTrigger: {
        trigger: '.categories-grid',
        start: 'top 80%'
    },
    duration: 0.6,
    y: 50,
    opacity: 0,
    stagger: 0.1
});

// Showcase cards animation
gsap.from('.showcase-card', {
    scrollTrigger: {
        trigger: '.category-cards-showcase',
        start: 'top 80%'
    },
    duration: 0.8,
    y: 50,
    opacity: 0,
    stagger: 0.15
});

// Generator section animation
gsap.from('.generator-input-section > *', {
    scrollTrigger: {
        trigger: '.generator-container',
        start: 'top 80%'
    },
    duration: 0.6,
    y: 30,
    opacity: 0,
    stagger: 0.1
});

// Footer animation
gsap.from('.footer-grid > div', {
    scrollTrigger: {
        trigger: '.footer',
        start: 'top 90%'
    },
    duration: 0.6,
    y: 30,
    opacity: 0,
    stagger: 0.1
});

/* =====================================================
   ADDITIONAL CSS ANIMATIONS
   ===================================================== */
const style = document.createElement('style');
style.textContent = `
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-5px); }
        75% { transform: translateX(5px); }
    }
    
    .navbar.scrolled {
        background: rgba(10, 10, 15, 0.98) !important;
    }
    
    [data-theme="light"] .navbar.scrolled {
        background: rgba(248, 250, 252, 0.98) !important;
    }
    
    .gift-box-wrapper.hidden {
        opacity: 0;
        pointer-events: none;
    }
    
    .nav-link.active {
        color: var(--accent-primary) !important;
    }
    
    .nav-link.active::after {
        width: 100% !important;
    }
    
    @media (max-width: 768px) {
        .floating-cards {
            display: none !important;
        }
    }
`;
document.head.appendChild(style);
